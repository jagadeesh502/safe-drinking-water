import React from 'react';
import './Contact.css';

function Contact() {
  return (
    <section className="contact">
      <div className="contact-content">
        <div className="contact-text">
          <h2>Contact Us</h2>
          <p>
            Have any questions or want to schedule a consultation? Feel free to reach out, and we'd love to hear from you!
          </p>
          <div className="contact-info">
            <div className="contact-item">
              <i className="fas fa-envelope"></i>
              <p>Email us at: <a href="mailto:contact@fashionstudio.com">purewater@gmail.com</a></p>
            </div>
            <div className="contact-item">
              <i className="fas fa-phone-alt"></i>
              <p>Call us at:+91 6301240600</p>
            </div>
            <div className="contact-item">
              <i className="fas fa-map-marker-alt"></i>
              
              <address><p>Visit us at:</p>prakash nagar,1st line narasaraopet.</address>
            </div>
          </div>
        </div>
        <div className="contact-form">
          <h3>Send Us a Message</h3>
          <form>
            <input type="text" placeholder="Your Name" required />
            <input type="email" placeholder="Your Email" required />
            <textarea placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
          </form>
        </div>
      </div>
    </section>
  );
}

export default Contact;