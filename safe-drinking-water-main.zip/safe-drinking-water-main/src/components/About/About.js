// src/About.js
import React from 'react';
import './About.css'; 

const About = () => {
    return (
      <body>
      <section class="about-us">
        <div class="about">
          <img src="https://i1.wp.com/www.rotaryindoreprofessionals.org/wp-content/uploads/2020/07/Safe-Drinking-Water-logo.png?fit=1056%2C1011&ssl=1" class="pic" />
          <div class="text">
            <h3>Drinking Water</h3>
            <h5>Awareness Of Safe Drinking Water</h5>
            <p>Safe and readily available water is important for public health, whether it is used for drinking, domestic use, food production or recreational purposes. Improved water supply and sanitation, and better management of water resources, can boost countries economic growth and can contribute greatly to poverty reduction.</p>
            <p>Sustainable Development Goal target 6.1 calls for universal and equitable access to safe and affordable drinking water. The target is tracked with the indicator of “safely managed drinking water services” available when needed, and free from faecal and 
              priority chemical contamination.</p>
            
          </div>
        </div>
      </section>
    </body>
    );
};

export default About;