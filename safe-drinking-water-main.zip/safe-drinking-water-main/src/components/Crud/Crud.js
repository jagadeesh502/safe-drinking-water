import React, { useState, useEffect } from "react";
import axios from "axios";
import './Crud.css';

const App = () => {
  const [data, setData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("Insert"); // Insert, Read, Update
  const [formData, setFormData] = useState({ id: "", name: "", email: "" });
  const [currentId, setCurrentId] = useState(null);

  useEffect(() => {
    // Fetch all users from the backend
    axios.get('http://localhost:5000/api/users')
      .then(response => {
        setData(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);

  const openModal = (mode, id = null) => {
    setModalMode(mode);
    setIsModalOpen(true);
    if (mode === "Update" || mode === "Read") {
      const selectedRow = data.find((item) => item.id === id);
      setFormData({ ...selectedRow });
      setCurrentId(id);
    } else {
      setFormData({ id: "", name: "", email: "" });
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setFormData({ id: "", name: "", email: "" });
    setCurrentId(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = () => {
    if (modalMode === "Insert") {
      axios.post('http://localhost:5000/api/users', formData)
        .then(response => {
          setData([...data, response.data]);
          closeModal();
        })
        .catch(error => {
          console.error('There was an error submitting the data!', error);
        });
    } else if (modalMode === "Update") {
      axios.put(`http://localhost:5000/api/users/${currentId}`, formData)
        .then(response => {
          setData(data.map(item => (item.id === currentId ? response.data : item)));
          closeModal();
        })
        .catch(error => {
          console.error('There was an error updating the data!', error);
        });
    }
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/api/users/${id}`)
      .then(() => {
        setData(data.filter(item => item.id !== id));
      })
      .catch(error => {
        console.error('There was an error deleting the data!', error);
      });
  };

  return (
    <div className="container">
      <button className="insert-button" onClick={() => openModal("Insert")}>
        Insert
      </button>

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h3>{modalMode} Data</h3>
            {(modalMode === "Insert" || modalMode === "Update") && (
              <form>
                <div>
                  <label>Name:</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <label>Email:</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>
              </form>
            )}
            {modalMode === "Read" && (
              <div>
                <p>
                  <strong>Name:</strong> {formData.name}
                </p>
                <p>
                  <strong>Email:</strong> {formData.email}
                </p>
              </div>
            )}
            <div>
              <button className="close-btn" onClick={closeModal}>
                Close
              </button>&nbsp;
              {(modalMode === "Insert" || modalMode === "Update") && (
                <button2 onClick={handleSubmit}>Submit</button2>
              )}
            </div>
          </div>
        </div>
      )}
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.email}</td>
              <td className="actions">
                <button className="read-btn" onClick={() => openModal("Read", item.id)}>Read</button>
                <button className="update-btn" onClick={() => openModal("Update", item.id)}>Update</button>
                <button className="delete-btn" onClick={() => handleDelete(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;


