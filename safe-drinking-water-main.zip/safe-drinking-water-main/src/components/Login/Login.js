import React,{useState} from "react";
import './Login.css';

function Login(){
    const [name,setName]=useState("");
    const [email,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const handleSubmit=(e)=>{
        e.preventDefault();
        console.log(name,email,password);
    }

    return(
        <>
        <form>
            <h1>Login</h1>
            <p>{name},{email},{password}</p>
            <label>Name:</label>
            <input type="text" placeholder="" value={name} onChange={(e)=>setName(e.target.value)}/><br/>
            <label>Email:</label>
            <input type="email" placeholder="" value={email} onChange={(e)=>setEmail(e.target.value)}/><br/>
            <label>Password:</label>
            <input type="password" placeholder="" value={password} onChange={(e)=>setPassword(e.target.value)}/><br/>
            <button onClick={handleSubmit}>Submit</button>

        </form>
        </>

    )
    
    
}
export default Login;
