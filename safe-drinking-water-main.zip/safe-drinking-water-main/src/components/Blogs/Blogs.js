import React from 'react';
import './Blogs.css'; // Import the CSS file for styling

const GridLayout = () => {
  return (
    <div className="grid-container">
      <div className="grid-item">
        <img src="https://www.deltaed.co.nz/wp-content/uploads/2012/08/49BRGI-LAB-BOTTLE-CAP-RED.jpg" alt="Image 1" />
        <p>A red cap usually indicates that the water is carbonated or sparkling</p>
        
      </div>
      <div className="grid-item">
        <img src="https://www.cupbarn.com/wp-content/uploads/2018/12/38mm-Plastic-Bottle-Cap-Blue-500x500.jpg" alt="Image 2" />
        <p>A blue cap usually indicates that the water is spring or mineral water</p>
      </div>
      <div className="grid-item">
        <img src="https://tse4.mm.bing.net/th?id=OIP.oUwZlDhF24xdLAm7LRruwAHaHa&pid=Api&P=0&h=180" alt="Image 3" />
        <p>A green cap on a water bottle usually indicates the water has added flavor</p>
      </div>
      <div className="grid-item">
        <img src="https://5.imimg.com/data5/SELLER/Default/2022/2/TB/JM/HI/40445105/water-bottle-screw-cap-500x500.jpg" alt="Image 4" />
        <p>It indicates that the water is processed or purified</p>
      </div>
      <div className="grid-item">
        <img src="https://tse3.mm.bing.net/th?id=OIP.q0B4ZygIW5TUqfH6l92ysQAAAA&pid=Api&P=0&h=180" alt="Image 5" />
        <p>It indicates that the water is breast cancer or charity events</p>
      </div>
    </div>
  );
};

export default GridLayout;
