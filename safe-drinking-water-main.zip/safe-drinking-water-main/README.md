<h1>Website Name:( SAFE DRINKING WATER )</h1>
<h3>Live Website Link:  https://voluble-moonbeam-1c927a.netlify.app/home</h3> 




.
🟢 " First, open the cmd of the computer and run the npx create-react-app command to create  a react app. "

🟢 " Then I created a navbar. So I created some components called home, reviews, dashboard, blogs, about. After that I linked up the components with navbar through React Router. "

🟢 " After that I added a name of the website on the home page and added a picture. After that I made some fake data and created a custom hook and loaded the data there. After that I used the custom hook to show some data at the bottom of the home page. "

🟢 " After that I showed some review data on the review page. Than I saw some chart data in the dashboard and added some quotation ans on the blog page. "

🟢 " After that I added some style to the website and run the npm run build command and hosted the website on netlify. "